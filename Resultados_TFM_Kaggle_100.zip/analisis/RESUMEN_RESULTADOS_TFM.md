# Resultados reales del experimento
Fecha UTC: 2026-10-17T19:41:55.515945+00:00
Muestras planificadas: 100
CIF encontrados: 100
CIF aceptados tras filtros: 71
CIF descartados: 29
Entradas ranking exploratorio: 71

## Métricas (GroupKFold por fórmula, media por pliegue)
| variable_objetivo   | modelo            |       MAE |     RMSE |         R2 | validacion                      |   filas_entrenamiento |   grupos |
|:--------------------|:------------------|----------:|---------:|-----------:|:--------------------------------|----------------------:|---------:|
| energy_above_hull   | Random Forest     | 0.0972417 | 0.222969 |  0.248234  | GroupKFold por formula reducida |                  1119 |      834 |
| energy_above_hull   | Gradient Boosting | 0.114425  | 0.23387  |  0.16753   | GroupKFold por formula reducida |                  1119 |      834 |
| energy_above_hull   | KNN               | 0.106972  | 0.245364 |  0.0934662 | GroupKFold por formula reducida |                  1119 |      834 |
| energy_above_hull   | MLP               | 0.155845  | 0.287099 | -0.373261  | GroupKFold por formula reducida |                  1119 |      834 |
| band_gap            | Random Forest     | 0.928472  | 1.25815  |  0.570326  | GroupKFold por formula reducida |                  1119 |      834 |
| band_gap            | Gradient Boosting | 0.982338  | 1.26787  |  0.564039  | GroupKFold por formula reducida |                  1119 |      834 |
| band_gap            | KNN               | 1.18367   | 1.6328   |  0.279587  | GroupKFold por formula reducida |                  1119 |      834 |
| band_gap            | MLP               | 1.26685   | 1.65023  |  0.263425  | GroupKFold por formula reducida |                  1119 |      834 |

## Resultados que NO se pueden afirmar
- No hay conductividad iónica calculada ni medida.
- Band gap electrónico no equivale a ventana electroquímica.
- La energía predicha por composición no es energía DFT del cristal generado.
- Estar cerca del objetivo generativo de energía no demuestra estabilidad.
- Ningún candidato se considera electrolito confirmado.

## PCA y clustering
{"estado": "PCA y clustering generados", "k": 5, "silhouette": {"2": 0.5692851833085117, "3": 0.7869613601404154, "4": 0.830174250417369, "5": 0.8315123659740679, "6": 0.757936776961006, "7": 0.7615827658761748}}